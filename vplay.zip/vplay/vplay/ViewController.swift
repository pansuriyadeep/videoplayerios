//
//  ViewController.swift
//  vplay
//
//  Created by Student on 21/03/24.
//  Copyright © 2024 Student. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController, AVPlayerViewControllerDelegate {
    var playerController = AVPlayerViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func button_start(_ sender: Any) {
        
        guard let url = URL(string: "https://docs.evostream.com/sample_content/assets/poppres240p.mp4")else {return}
  
        let player = AVPlayer(url: url)
    playerController = AVPlayerViewController()
    playerController.player = player
    playerController.allowsPictureInPicturePlayback = true
    playerController.delegate = self
    playerController.player?.play()
       
        
        self.present(playerController, animated: true, completion: nil)
   }
}
